import React, { useState, useEffect } from 'react';
import {
  Upload,
  FileText,
  Wand2,
  Shield,
  Clock,
  Bot,
  MessageSquare,
  ChevronRight,
  Github,
  Twitter,
  Linkedin,
  X,
  Lock,
  CheckCircle2,
  Award,
  Star,
  Quote
} from 'lucide-react';

function App() {
  const [showExitPopup, setShowExitPopup] = useState(false);
  const [timeLeft, setTimeLeft] = useState(1800); // 30 minutes in seconds

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => Math.max(0, prev - 1));
    }, 1000);

    const handleMouseLeave = (e: MouseEvent) => {
      if (e.clientY <= 0) {
        setShowExitPopup(true);
      }
    };

    document.addEventListener('mouseleave', handleMouseLeave);

    return () => {
      clearInterval(timer);
      document.removeEventListener('mouseleave', handleMouseLeave);
    };
  }, []);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-[#E4F2FA]">
      {/* Hero Section */}
      <header className="bg-gradient-to-r from-[#175676] to-[#5BBAD5] text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-black/20 z-10"></div>
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: 'url("https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?auto=format&fit=crop&q=80")',
            backgroundAttachment: 'fixed'
          }}
        ></div>
        
        <nav className="container mx-auto px-6 py-4 flex items-center justify-between relative z-20">
          <div className="text-2xl font-bold flex items-center gap-2">
            <Wand2 className="h-8 w-8" />
            Reziume
          </div>
          <div className="hidden md:flex items-center gap-8">
            <a href="#features" className="hover:text-[#E4F2FA] transition">Features</a>
            <a href="#pricing" className="hover:text-[#E4F2FA] transition">Pricing</a>
            <a href="#contact" className="hover:text-[#E4F2FA] transition">Contact</a>
            <button className="bg-[#E04A58] hover:bg-[#D6455F] px-6 py-2 rounded-lg font-semibold transition">
              Sign In
            </button>
          </div>
        </nav>
        
        <div className="container mx-auto px-6 py-24 flex flex-col md:flex-row items-center gap-12 relative z-20">
          <div className="flex-1 space-y-8">
            <div className="inline-block px-4 py-2 bg-[#5BBAD5]/30 rounded-full text-sm font-medium mb-4">
              🎉 Special Launch Offer - 50% Off Premium Plan
            </div>
            <h1 className="text-4xl md:text-6xl font-bold leading-tight">
              Transform Your Resume Into a Job-Winning Masterpiece
            </h1>
            <p className="text-xl text-[#E4F2FA]">
              Upload your resume, paste the job description, and let our AI create a highly customized resume tailored for the job.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <button className="bg-[#E04A58] hover:bg-[#D6455F] px-8 py-4 rounded-lg font-semibold text-lg transition flex items-center justify-center gap-2 w-full sm:w-auto">
                Get Started for Free
                <ChevronRight className="h-5 w-5" />
              </button>
              <button className="bg-white/20 hover:bg-white/30 px-8 py-4 rounded-lg font-semibold text-lg transition flex items-center justify-center gap-2 backdrop-blur-sm w-full sm:w-auto">
                Watch Demo
                <FileText className="h-5 w-5" />
              </button>
            </div>
            <div className="flex items-center gap-4 text-sm">
              <div className="flex -space-x-2">
                <img src="https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?w=50&h=50&fit=crop" className="w-8 h-8 rounded-full border-2 border-white" alt="User" />
                <img src="https://images.unsplash.com/photo-1560250097-0b93528c311a?w=50&h=50&fit=crop" className="w-8 h-8 rounded-full border-2 border-white" alt="User" />
                <img src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=50&h=50&fit=crop" className="w-8 h-8 rounded-full border-2 border-white" alt="User" />
              </div>
              <p>Joined by 10,000+ job seekers</p>
            </div>
          </div>
          <div className="flex-1">
            <div className="bg-white p-6 rounded-xl shadow-2xl">
              <img 
                src="https://images.unsplash.com/photo-1542744094-24638eff58bb?auto=format&fit=crop&q=80"
                alt="AI Resume Analysis"
                className="rounded-lg"
              />
              <div className="mt-4 p-4 bg-[#E4F2FA] rounded-lg">
                <h3 className="font-semibold text-[#175676]">Live Resume Preview</h3>
                <p className="text-[#175676]/80 text-sm">See how our AI transforms your resume in real-time</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Trust Badges */}
      <div className="bg-white py-8 border-y border-[#E4F2FA]">
        <div className="container mx-auto px-6">
          <div className="flex flex-wrap justify-center items-center gap-8">
            <div className="flex items-center gap-2">
              <Shield className="h-6 w-6 text-[#175676]" />
              <span className="text-sm font-medium">256-bit SSL Encryption</span>
            </div>
            <div className="flex items-center gap-2">
              <Lock className="h-6 w-6 text-[#175676]" />
              <span className="text-sm font-medium">GDPR Compliant</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-6 w-6 text-[#5BBAD5]" />
              <span className="text-sm font-medium">10,000+ Happy Users</span>
            </div>
            <div className="flex items-center gap-2">
              <Award className="h-6 w-6 text-[#E04A58]" />
              <span className="text-sm font-medium">#1 Resume Builder</span>
            </div>
          </div>
        </div>
      </div>

      {/* How It Works */}
      <section className="py-24 bg-white relative overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center opacity-5"
          style={{
            backgroundImage: 'url("https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&q=80")',
            backgroundAttachment: 'fixed'
          }}
        ></div>
        <div className="container mx-auto px-6 relative z-10">
          <h2 className="text-4xl font-bold text-center mb-16 text-[#175676]">How It Works</h2>
          <div className="grid md:grid-cols-3 gap-12">
            {[
              {
                icon: <Upload className="h-12 w-12 text-[#175676]" />,
                title: "Upload Your Resume",
                description: "Upload your existing resume to Reziume.",
                image: "https://images.unsplash.com/photo-1586281380117-5a60ae2050cc?auto=format&fit=crop&q=80&w=400"
              },
              {
                icon: <FileText className="h-12 w-12 text-[#175676]" />,
                title: "Paste Job Description",
                description: "Insert the LinkedIn job description for the job you're applying for.",
                image: "https://images.unsplash.com/photo-1600880292203-757bb62b4baf?auto=format&fit=crop&q=80&w=400"
              },
              {
                icon: <Wand2 className="h-12 w-12 text-[#175676]" />,
                title: "Generate Customized Resume",
                description: "Receive a professional, tailored resume optimized for the specific role.",
                image: "https://images.unsplash.com/photo-1664575602554-2087b04935a5?auto=format&fit=crop&q=80&w=400"
              }
            ].map((step, index) => (
              <div key={index} className="text-center space-y-4 group">
                <div className="relative overflow-hidden rounded-xl">
                  <div className="absolute inset-0 bg-gradient-to-t from-[#175676]/60 to-transparent"></div>
                  <img 
                    src={step.image} 
                    alt={step.title}
                    className="w-full h-48 object-cover transform group-hover:scale-105 transition duration-500"
                  />
                  <div className="absolute bottom-4 left-4 right-4">
                    <div className="bg-white/90 backdrop-blur-sm p-4 rounded-lg shadow-lg">
                      <div className="flex justify-center mb-2">{step.icon}</div>
                      <h3 className="text-xl font-semibold text-[#175676]">{step.title}</h3>
                    </div>
                  </div>
                </div>
                <p className="text-gray-600">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 bg-[#E4F2FA]">
        <div className="container mx-auto px-6">
          <h2 className="text-4xl font-bold text-center mb-16 text-[#175676]">What Our Users Say</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                quote: "Reziume helped me land my dream job at Google. The AI customization is incredible!",
                name: "Sarah Chen",
                title: "Software Engineer",
                image: "https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?w=100&h=100&fit=crop",
                company: "Previously at StartupX"
              },
              {
                quote: "I received more interview calls in one week than I did in months. This tool is a game-changer!",
                name: "Michael Rodriguez",
                title: "Product Manager",
                image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=100&h=100&fit=crop",
                company: "Hired at TechCorp"
              },
              {
                quote: "The customization feature saved me hours of work. Worth every penny!",
                name: "Emily Thompson",
                title: "Marketing Director",
                image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=100&h=100&fit=crop",
                company: "Now at BigBrand Inc"
              }
            ].map((testimonial, index) => (
              <div key={index} className="bg-white p-6 rounded-xl shadow-lg">
                <div className="flex items-center gap-2 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 fill-[#E04A58] text-[#E04A58]" />
                  ))}
                </div>
                <Quote className="h-8 w-8 text-[#5BBAD5] mb-4" />
                <p className="text-gray-700 mb-6">{testimonial.quote}</p>
                <div className="flex items-center gap-4">
                  <img 
                    src={testimonial.image} 
                    alt={testimonial.name}
                    className="w-12 h-12 rounded-full"
                  />
                  <div>
                    <h4 className="font-semibold text-[#175676]">{testimonial.name}</h4>
                    <p className="text-sm text-gray-600">{testimonial.title}</p>
                    <p className="text-sm text-[#5BBAD5]">{testimonial.company}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Company Logos */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <h3 className="text-center text-[#175676] font-semibold mb-8">Our Users Have Landed Jobs At</h3>
          <div className="flex flex-wrap justify-center items-center gap-12">
            <img src="https://images.unsplash.com/photo-1611944212129-29977ae1398c?auto=format&fit=crop&q=80&w=200" alt="Tech Company" className="h-12 grayscale hover:grayscale-0 transition" />
            <img src="https://images.unsplash.com/photo-1611944212129-29977ae1398c?auto=format&fit=crop&q=80&w=200" alt="Tech Company" className="h-12 grayscale hover:grayscale-0 transition" />
            <img src="https://images.unsplash.com/photo-1611944212129-29977ae1398c?auto=format&fit=crop&q=80&w=200" alt="Tech Company" className="h-12 grayscale hover:grayscale-0 transition" />
          </div>
          <div className="text-center mt-8">
            <p className="text-[#175676] font-semibold">5,000+ Resumes Customized | 85% Success Rate</p>
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="py-24 bg-[#E4F2FA]">
        <div className="container mx-auto px-6">
          <h2 className="text-4xl font-bold text-center mb-16 text-[#175676]">Key Features</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: <Bot className="h-8 w-8 text-[#175676]" />,
                title: "AI-Powered Resume Tailoring",
                description: "Advanced AI algorithms customize your resume perfectly."
              },
              {
                icon: <FileText className="h-8 w-8 text-[#175676]" />,
                title: "Job-Specific Customization",
                description: "Tailored to match specific job requirements."
              },
              {
                icon: <Clock className="h-8 w-8 text-[#175676]" />,
                title: "Quick Turnaround",
                description: "Get your optimized resume in seconds."
              },
              {
                icon: <Shield className="h-8 w-8 text-[#175676]" />,
                title: "Secure Data Privacy",
                description: "Your data is encrypted and secure."
              }
            ].map((feature, index) => (
              <div key={index} className="p-6 bg-white rounded-xl shadow hover:shadow-lg transition group">
                <div className="mb-4 transform group-hover:scale-110 transition">{feature.icon}</div>
                <h3 className="text-xl font-semibold mb-2 text-[#175676]">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="py-24 bg-white">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4 text-[#175676]">Simple Pricing</h2>
            <p className="text-xl text-gray-600">Choose the perfect plan for your needs</p>
            {timeLeft > 0 && (
              <div className="mt-4 inline-block bg-[#E04A58]/10 text-[#E04A58] px-4 py-2 rounded-full">
                <span className="font-semibold">🔥 Special Launch Offer ends in: {formatTime(timeLeft)}</span>
              </div>
            )}
          </div>
          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {[
              {
                title: "Free",
                price: "$0",
                features: [
                  "3 Resume Customizations",
                  "Basic Features",
                  "Standard Support",
                  "Basic Templates",
                  "Export as PDF"
                ],
                cta: "Sign Up for Free",
                highlighted: false
              },
              {
                title: "Premium",
                price: "$9.99",
                period: "/month",
                features: [
                  "Unlimited Customizations",
                  "Advanced AI Features",
                  "Priority Customer Support",
                  "Premium Templates",
                  "Export in All Formats",
                  "Cover Letter Generator",
                  "LinkedIn Profile Optimizer"
                ],
                cta: "Start Free Trial",
                highlighted: true,
                badge: "MOST POPULAR"
              },
              {
                title: "Permanent",
                price: "$199",
                period: "/lifetime",
                features: [
                  "All Premium Features",
                  "Lifetime Access",
                  "Priority Support",
                  "Free Updates",
                  "Personal Career Coach",
                  "Interview Preparation",
                  "Job Search Strategy"
                ],
                cta: "Get Lifetime Access",
                highlighted: false
              }
            ].map((plan, index) => (
              <div 
                key={index}
                className={`p-8 rounded-xl relative ${
                  plan.highlighted 
                    ? 'bg-[#175676] text-white shadow-xl scale-105 transform' 
                    : 'bg-white text-gray-900 shadow-lg'
                }`}
              >
                {plan.badge && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <span className="bg-[#E04A58] text-white px-4 py-1 rounded-full text-sm font-semibold">
                      {plan.badge}
                    </span>
                  </div>
                )}
                <h3 className="text-2xl font-bold mb-4">{plan.title}</h3>
                <div className="mb-6">
                  <span className="text-4xl font-bold">{plan.price}</span>
                  {plan.period && <span className="text-lg">{plan.period}</span>}
                </div>
                <ul className="space-y-4 mb-8">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-center gap-2">
                      <CheckCircle2 className="h-5 w-5 text-[#5BBAD5]" />
                      {feature}
                    </li>
                  ))}
                </ul>
                <button
                  className={`w-full py-3 rounded-lg font-semibold transition ${
                    plan.highlighted
                      ? 'bg-[#E04A58] text-white hover:bg-[#D6455F]'
                      : 'bg-[#175676] text-white hover:bg-[#5BBAD5]'
                  }`}
                >
                  {plan.cta}
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact */}
      <section id="contact" className="py-24 bg-[#E4F2FA]">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-4xl font-bold text-center mb-16 text-[#175676]">Get in Touch</h2>
            <div className="grid md:grid-cols-2 gap-12">
              <div>
                <h3 className="text-2xl font-semibold mb-6 text-[#175676]">Contact Us</h3>
                <form className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-[#175676] mb-2">Name</label>
                    <input
                      type="text"
                      className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-[#5BBAD5] focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-[#175676] mb-2">Email</label>
                    <input
                      type="email"
                      className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-[#5BBAD5] focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-[#175676] mb-2">Message</label>
                    <textarea
                      rows={4}
                      className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-[#5BBAD5] focus:border-transparent"
                    />
                  </div>
                  <button className="w-full bg-[#E04A58] text-white py-3 rounded-lg font-semibold hover:bg-[#D6455F] transition">
                    Send Message
                  </button>
                </form>
              </div>
              <div>
                <h3 className="text-2xl font-semibold mb-6 text-[#175676]">FAQ</h3>
                <div className="space-y-6">
                  <div>
                    <h4 className="font-semibold mb-2 text-[#175676]">How does Reziume protect my data?</h4>
                    <p className="text-gray-600">
                      We use industry-standard encryption and security measures to protect your personal information. Your data is never shared with third parties.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2 text-[#175676]">Can I use this for multiple jobs?</h4>
                    <p className="text-gray-600">
                      Yes! Our Premium plan allows you to create unlimited customized resumes for different job applications.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#175676] text-white py-12">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="text-2xl font-bold flex items-center gap-2 mb-4">
                <Wand2 className="h-6 w-6" />
                Reziume
              </div>
              <p className="text-gray-300">
                Transform your resume into a job-winning masterpiece with AI-powered customization.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-gray-300">
                <li><a href="#features" className="hover:text-white transition">Features</a></li>
                <li><a href="#pricing" className="hover:text-white transition">Pricing</a></li>
                <li><a href="#contact" className="hover:text-white transition">Contact</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Legal</h4>
              <ul className="space-y-2 text-gray-300">
                <li><a href="#" className="hover:text-white transition">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-white transition">Terms of Service</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Connect</h4>
              <div className="flex gap-4">
                <a href="#" className="hover:text-[#5BBAD5] transition">
                  <Twitter className="h-6 w-6" />
                </a>
                <a href="#" className="hover:text-[#5BBAD5] transition">
                  <Github className="h-6 w-6" />
                </a>
                <a href="#" className="hover:text-[#5BBAD5] transition">
                  <Linkedin className="h-6 w-6" />
                </a>
              </div>
            </div>
          </div>
          <div className="border-t border-[#5BBAD5]/20 mt-12 pt-8 text-center text-gray-300">
            © 2025 Reziume. All rights reserved.
          </div>
        </div>
      </footer>

      {/* Exit Intent Popup */}
      {showExitPopup && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-8 max-w-md mx-4">
            <button 
              onClick={() => setShowExitPopup(false)}
              className="absolute top-4 right-4 text-gray-500 hover:text-gray-700"
            >
              <X className="h-6 w-6" />
            </button>
            <div className="text-center">
              <h3 className="text-2xl font-bold mb-4 text-[#175676]">Wait! Don't Miss Out!</h3>
              <p className="text-gray-600 mb-6">
                Get 50% off our Premium Plan if you sign up now!
              </p>
              <button 
                onClick={() => setShowExitPopup(false)}
                className="w-full bg-[#E04A58] text-white py-3 rounded-lg font-semibold hover:bg-[#D6455F] transition mb-4"
              >
                Claim My 50% Discount
              </button>
              <button 
                onClick={() => setShowExitPopup(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                No thanks, I'll pass
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;